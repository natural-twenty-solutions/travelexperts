<?php
	session_start();
	include ("variables.php");
	include("functions.php");
	$title="Travel Expert Internal Admin Page - Insert Agent";
	require ("header.php");
		
?>
<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
	<script>
		function redirect()
		{
		newwindow=window.open("\insertCustomer.php");
	
		
		}
	</script>
	
</head>
<body>
	<center>
		<?php include("bodyheader.php") ?>
	
		<div class="w3-middle w3-dark-grey w3-opacity  w3-hover-opacity-off" style="width:50%;">
			<h2 style="margin-left:40px;">Customer Login</h2>
			<h2 style="margin-left:40px; color:red">
				<?php
					if (isset($_SESSION["message"]))
						print($_SESSION["message"]);
						unset($_SESSION["message"]);
						
				?>
			</h2>
			
			<form method='get' action='checkcustlogin.php' style="top:50%"> <!-- checklogin.php will receive the form data and verify the authority-->
				User ID: <input type='text' name='userid' /></br>
				Password:<input type='password' name='password'/></br>
				<input type='submit' value='Log In'/>
				<button onclick="redirect()">New Customer Registration</button> 
			</form>
		</div>
	</center>
	

<?php
	include ("footer.php");
?>